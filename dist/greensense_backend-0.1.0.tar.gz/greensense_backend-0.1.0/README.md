to work requires a valid sqlite db inside root dir
